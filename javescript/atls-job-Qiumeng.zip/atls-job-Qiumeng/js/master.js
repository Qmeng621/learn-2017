function btnHome() {
    var homeButtonContent = document.getElementById("home");
    var infoButtonContent = document.getElementById("info");
    var alertButtonContent = document.getElementById("alert");
    var hydropsButtonContent = document.getElementById("hydrops");
    var drainageButtonContent = document.getElementById("drainage");
    var systemAdminButtonContent = document.getElementById("systemAdmin");

    homeButtonContent.className = "mapbox";
    infoButtonContent.className = "hide";
    alertButtonContent.className = "hide";
    hydropsButtonContent.className = "hide";
    drainageButtonContent.className = "hide";
    systemAdminButtonContent.className = "hide";
}

function btnInfo() {
    var homeButtonContent = document.getElementById("home");
    var infoButtonContent = document.getElementById("info");
    var alertButtonContent = document.getElementById("alert");
    var hydropsButtonContent = document.getElementById("hydrops");
    var drainageButtonContent = document.getElementById("drainage");
    var systemAdminButtonContent = document.getElementById("systemAdmin");

    homeButtonContent.className = "hide";
    infoButtonContent.className = "mapbox";
    alertButtonContent.className = "hide";
    hydropsButtonContent.className = "hide";
    drainageButtonContent.className = "hide";
    systemAdminButtonContent.className = "hide";
}

function btnAlert() {
    var homeButtonContent = document.getElementById("home");
    var infoButtonContent = document.getElementById("info");
    var alertButtonContent = document.getElementById("alert");
    var hydropsButtonContent = document.getElementById("hydrops");
    var drainageButtonContent = document.getElementById("drainage");
    var systemAdminButtonContent = document.getElementById("systemAdmin");

    homeButtonContent.className = "hide";
    infoButtonContent.className = "hide";
    alertButtonContent.className = "mapbox";
    hydropsButtonContent.className = "hide";
    drainageButtonContent.className = "hide";
    systemAdminButtonContent.className = "hide";
}

function btnHydrops() {
    var homeButtonContent = document.getElementById("home");
    var infoButtonContent = document.getElementById("info");
    var alertButtonContent = document.getElementById("alert");
    var hydropsButtonContent = document.getElementById("hydrops");
    var drainageButtonContent = document.getElementById("drainage");
    var systemAdminButtonContent = document.getElementById("systemAdmin");

    homeButtonContent.className = "hide";
    infoButtonContent.className = "hide";
    alertButtonContent.className = "hide";
    hydropsButtonContent.className = "mapbox";
    drainageButtonContent.className = "hide";
    systemAdminButtonContent.className = "hide";
}

function btnDrainage() {
    var homeButtonContent = document.getElementById("home");
    var infoButtonContent = document.getElementById("info");
    var alertButtonContent = document.getElementById("alert");
    var hydropsButtonContent = document.getElementById("hydrops");
    var drainageButtonContent = document.getElementById("drainage");
    var systemAdminButtonContent = document.getElementById("systemAdmin");

    homeButtonContent.className = "hide";
    infoButtonContent.className = "hide";
    alertButtonContent.className = "hide";
    hydropsButtonContent.className = "hide";
    drainageButtonContent.className = "mapbox";
    systemAdminButtonContent.className = "hide";
}

function btnSystemAdmin() {
    var homeButtonContent = document.getElementById("home");
    var infoButtonContent = document.getElementById("info");
    var alertButtonContent = document.getElementById("alert");
    var hydropsButtonContent = document.getElementById("hydrops");
    var drainageButtonContent = document.getElementById("drainage");
    var systemAdminButtonContent = document.getElementById("systemAdmin");

    homeButtonContent.className = "hide";
    infoButtonContent.className = "hide";
    alertButtonContent.className = "hide";
    hydropsButtonContent.className = "hide";
    drainageButtonContent.className = "hide";
    systemAdminButtonContent.className = "mapbox";
}
